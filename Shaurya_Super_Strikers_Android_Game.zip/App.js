import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, SafeAreaView } from 'react-native';
import { StatusBar } from 'expo-status-bar';

export default function App() {
  const [score, setScore] = useState(0);
  const [balls, setBalls] = useState(0);
  const [wickets, setWickets] = useState(0);
  const [result, setResult] = useState(null);
  const maxOvers = 2;
  const ballsPerOver = 6;

  const playBall = () => {
    if (balls >= maxOvers * ballsPerOver || wickets >= 2) return;

    const outcome = Math.floor(Math.random() * 6);
    setBalls(balls + 1);

    if (outcome === 0) {
      setWickets(wickets + 1);
    } else {
      setScore(score + outcome);
    }

    if (balls + 1 === maxOvers * ballsPerOver || wickets + (outcome === 0 ? 1 : 0) >= 2) {
      setResult(score >= 20 ? 'Shaurya Super Strikers WIN! 🏆' : 'Shaurya Super Strikers LOSE 😓');
    }
  };

  const resetMatch = () => {
    setScore(0);
    setBalls(0);
    setWickets(0);
    setResult(null);
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="light" />
      <Text style={styles.title}>🏏 Shaurya Super Strikers</Text>
      <Text style={styles.subtitle}>Quick Match Mode - SPL 2025</Text>
      <View style={styles.card}>
        <Text style={styles.score}>Score: {score}/{wickets}</Text>
        <Text style={styles.balls}>Balls: {balls} / {maxOvers * ballsPerOver}</Text>
        {result ? (
          <>
            <Text style={styles.result}>{result}</Text>
            <TouchableOpacity style={styles.button} onPress={resetMatch}>
              <Text style={styles.buttonText}>Play Again</Text>
            </TouchableOpacity>
          </>
        ) : (
          <TouchableOpacity style={styles.button} onPress={playBall}>
            <Text style={styles.buttonText}>Bowl ➡️</Text>
          </TouchableOpacity>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#062e1a',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#ffe600',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#ccc',
    marginBottom: 20,
    fontStyle: 'italic',
  },
  card: {
    backgroundColor: '#114d2a',
    padding: 24,
    borderRadius: 16,
    width: '100%',
    alignItems: 'center',
  },
  score: {
    fontSize: 24,
    color: 'white',
    marginBottom: 10,
  },
  balls: {
    fontSize: 16,
    color: 'white',
    marginBottom: 20,
  },
  result: {
    fontSize: 22,
    color: '#ffe600',
    fontWeight: 'bold',
    marginBottom: 16,
  },
  button: {
    backgroundColor: '#ffe600',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 50,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1f1f1f',
  },
});
